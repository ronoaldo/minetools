
mapserver.bridge.add_locators = function(data)
  -- data.locators = locator.beacons
end
