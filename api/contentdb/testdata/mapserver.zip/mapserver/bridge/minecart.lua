
mapserver.bridge.add_minecart = function(data)
  data.minecarts = minecart.get_cart_list()
end
